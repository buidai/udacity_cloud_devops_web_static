Domain name: https://d3fise8tqw0wl9.cloudfront.net/
Web-stie endpoint: http://daibq2-bucket.s3-website.us-east-1.amazonaws.com/
S3 Object URL: https://daibq2-bucket.s3.amazonaws.com/index.html
